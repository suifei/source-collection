### Indice

* [Algoritmi e Strutture Dati](#algoritmi-e-strutture-dati)
* [Android](#android)
* [Architettura degli Elaboratori](#architettura-degli-elaboratori)
* [Assembly](#assembly)
* [Bash / Shell](#bash--shell)
* [C](#c)
* [C#](#csharp)
* [C++](#cpp)
* [Database](#database)
    * [SQL](#sql)
* [Delphi](#delphi)
* [DevOps](#devops)
* [Embedded](#embedded)
    * [Arduino](#arduino)
* [Generale](#generale)
* [Java](#java)
* [JavaScript](#javascript)
    * [Vue.js](#vuejs)
* [Julia](#julia)
* [Machine Learning](#machine-learning)
* [Misto](#misto)
* [Mobile](#mobile)
* [Networking](#networking)
* [Pascal](#pascal)
* [Php](#php)
* [Programmazione](#programmazione)
* [Python](#python)
* [Ruby](#ruby)
* [Sistemi Informativi](#sistemi-informativi)
* [Sistemi Operativi](#sistemi-operativi)
    * [Linux](#linux)
* [Strumenti di sviluppo](#strumenti-di-sviluppo)
    * [Git](#git)
    * [Maven](#maven)
* [Web](#web)
* [Workshop](#workshop)


### Android

* [Corso Java - Android](https://www.youtube.com/playlist?list=PL0qAPtx8YtJeqmBWbE1Rbac2QWHoPCjR2) - Fabrizio Camuso


### Algoritmi e Strutture Dati

* [AlgoMOOC - Algoritmi quotidiani](https://www.youtube.com/playlist?list=PLjTV6y5YWc5HNnLyXkzUe9IlkG2n6guxU) - Alessandro Bogliolo
* [Algoritmi e Programmazione (C)](https://www.youtube.com/playlist?list=PLUFFnpJdi99nqESTPaxlPMOF7yEEb8_sS) - P. Camurati, G. Cabodi, Politecnico di Torino
* [Algoritmi e Strutture Dati]() - A. Montresor, Università di Trento
* [Algoritmi e Strutture Dati](https://www.youtube.com/playlist?list=PLO4y9a8lTpK2TViOKbk-NjDBvL4RXDwYY) - R. Grossi, Università di Pisa


### Architettura degli Elaboratori

* [Architettura degli Elaboratori](https://www.youtube.com/playlist?list=PLhEwqlL10MqMYYiR5NqMblyyQr1ss-b8q) - A. Sperduti, Università di Padova
* [CArcMOOC - Computer Architecture UniurbIT](https://www.youtube.com/playlist?list=PLjTV6y5YWc5H2fefaz78qCeSKWj-k_-pY) - Alessandro Bogliolo, Università di Urbino


### Assembly

* [Assembler x86](https://www.youtube.com/playlist?list=PLUJjY3hQLJ3NHQ9315KVvgiZ3v2FLtcbs)
* [Assembly x86](https://www.youtube.com/playlist?list=PL4GzWsD6ECaXVzneIlSV62plQPdWXIZ_h) - Leonardo Boselli


### Bash / Shell

* [Programmazione di sistema - Bash](https://www.youtube.com/playlist?list=PLhlcRDRHVUzR-5TKDC1VPMtyhEyyQ5uwy) - Nicola Bicocchi


### C

* [Corso C Italiano](https://www.youtube.com/playlist?list=PLP5MAKLy8lP9J2blw2HWEDnaNjmvUW-QG) - Edoardo Midali
* [Corso di programmazione in C](https://www.youtube.com/playlist?list=PLO4y9a8lTpK2ugwPRLN_1oOrlzX9Zc9It) - R. Rizzi, Università di Verona
* [Corso di programmazione in C](https://www.youtube.com/playlist?list=PLrEMgOSrS_3cFJpM2gdw8EGFyRBZOyAKY) - Salvatore Sanfilippo
* [Linguaggio C - Corso completo](https://www.youtube.com/playlist?list=PL83Ordjpzm5oUl7tFEjc4iirkPBiv7FxR) - Programmazione Time


### <a id="csharp"></a>C\#

* [Programmazione ad oggetti in C#](https://www.youtube.com/playlist?list=PLktbfd3yXeH8yQpHM3O468k8l-aTC6Hl6) - G. Pellegrini Parisi


### <a id="cpp"></a>C++

* [C++ 11](https://www.youtube.com/playlist?list=PL0qAPtx8YtJfZpJD7uFxAXglkiHSEhktG) - Fabrizio Camuso
* [C++ 23/26 - Modern First](https://www.youtube.com/playlist?list=PLd6QTB-nRibM85WylqKvcmdMMxdOLnwiP) - Fabrizio Camuso
* [C++ libreria QT - playlist 1](https://www.youtube.com/playlist?list=PL0qAPtx8YtJdH4GVwL_3QeJjPcz3DHE2t) - Fabrizio Camuso
* [Corso C++ 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP85m_fZy3TkWqB_8Zt5Q5aK) - Edoardo Midali


### Database

* [Basi di Dati](https://www.youtube.com/playlist?list=PLAQopGWlIcyZ7CN1sefdnCusfoodLP931) - T. Catarci, Università La Sapienza di Roma
* [Corso progettazione database](https://www.youtube.com/playlist?list=PL0qAPtx8YtJcJPSV4sOfhLtPbtQ-yycFH) - Fabrizio Camuso


#### SQL

* [Corso SQL](https://www.youtube.com/playlist?list=PLE555DB6188C967AC) - Fabrizio Camuso
* [Corso SQL Completo 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP_zsv6uijqYTIjdVEYgWf44) - Edoardo Midali


### Delphi

* [Videocorso Delphi/Lazarus](https://www.youtube.com/playlist?list=PLF75FB30719A09FA2) - Fabrizio Camuso


### DevOps

* [Corso DevOps](https://www.youtube.com/playlist?list=PLU2FPKLp7ojKcxrKXr1cFmXH81tMK4P3E) - Michele Ferracin
* [DevOps con GitHub Actions](https://www.youtube.com/playlist?list=PLoZNHBEyxFQHOR8EiAD_tQnRAP49_Ev24) - Giovanni Pace
* [Docker - EmmeCiLab](https://www.youtube.com/playlist?list=PLCbSCJEIR6CpDJw4MawjHlgbsP3IG376e) - Mauro Cicolella


### Embedded

#### Arduino

* [Arduino Cookbook - Corso di Arduino (400+ video)](https://www.youtube.com/playlist?list=PL9_01HM23dGEDNNfR6BtlDWD8DDoAcLOT) - Paolo Aliverti
* [Corso Arduino 2014](https://www.youtube.com/playlist?list=PLA27EZBY5vePO9T6YP3rH8LTTdylz69VE) - POuL Politecnico di Milano


### Generale

* [Automi e Linguaggi Formali](https://www.youtube.com/playlist?list=PLhEwqlL10MqNz1pA7R5jnB_gsMIhDOe5X) - Davide Bresolin, Gilberto Filè, Università di Padova
* [Concetti di Informatica](https://www.youtube.com/playlist?list=PLCbSCJEIR6CpTx_nIWA3N3TEdyoRBzWCt) - Mauro Cicolella
* [Crittografia 2023](https://www.youtube.com/playlist?list=PLQBZ1Z0ZLjQBesf3ZPxEL-qqhFHrcNgCb) - Alessandro Zaccagnini
* [Espressioni regolari - RegEx](https://www.youtube.com/playlist?list=PLCbSCJEIR6Co72vs-7KRCiCgaC3ht-HYM) - Mauro Cicolella
* [Fondamenti di Informatica](https://www.youtube.com/playlist?list=PLUL1bzfXcbX3g2cIcTFdmvj5yawQtUOxJ) - C. De Stefano, Università di Cassino e del Lazio Meridionale
* [Informatica](https://didattica.polito.it/pls/portal30/sviluppo.videolezioni.vis?cor=232) - Marco Mezzalama, Politecnico di Torino
* [Informatica di Base - Corso intensivo](https://www.youtube.com/playlist?list=PLG31HS6yEI8dv6TUmv9w0W6YmEAQm0P2q) - G. Pellegrini Parisi
* [Informatica I - Modelli dell'Informatica](https://www.youtube.com/playlist?list=PLAQopGWlIcyalkb2baN9mnotsdBm5Vbkc) - A. Marchetti Spaccamela, Università La Sapienza di Roma
* [Sistemi di Calcolo](https://www.youtube.com/playlist?list=PLAQopGWlIcybT12h7fjVvlGAeSqOKDnTA) - C. Demetrescu, Università La Sapienza di Roma
* [Teoria dell'informazione](https://www.youtube.com/playlist?list=PL0qAPtx8YtJeGo5g4Esi7tm6kHPRivkvb) - Fabrizio Camuso


### Java

* [Corso Base Spring Boot](https://www.youtube.com/playlist?list=PLoZNHBEyxFQHFkgxYwri50YEmbiRADl-O) - Giovanni Pace
* [Corso di Java Spring Framework](https://www.youtube.com/playlist?list=PLCbSCJEIR6CqgCLyVzqp49xOm8A5YDTKA) - Mauro Cicolella
* [Corso di JPA Java Persistence API](https://www.youtube.com/playlist?list=PLCbSCJEIR6Co1aPvFfPuIsRGouF9D0Jk3) - Mauro Cicolella
* [Corso Java in Italiano COMPLETO 2023/2024](https://www.youtube.com/playlist?list=PLUnSLr48xh3CAuL_Q0VAjthv0WbPuQQRR) - Code Brothers
* [Design Patterns in Java](https://www.youtube.com/playlist?list=PLCbSCJEIR6Cq-ac90TGvJ8Wo8TtyZ4nhu) - Mauro Cicolella
* [Esercitazioni di Spring Boot](https://www.youtube.com/playlist?list=PLCbSCJEIR6CpGchit9OCI6fX_qVYs78d_) - Mauro Cicolella
* [Java EE](https://www.youtube.com/playlist?list=PLjGYWJ4Dcy-erfReHXB9Ush0cREGSmyIe) - Sonia Zorba
* [Programmazione a Oggetti (Java)](https://www.youtube.com/playlist?list=PLUFFnpJdi99kewGZIHpCDgarZER_-J1am) - M. Torchiano, Politecnico di Torino
* [Programmazione ad Oggetti - Java](https://www.youtube.com/playlist?list=PLhlcRDRHVUzTruZmXalUSJAK26pouP8ST) - Nicola Bicocchi
* [Spring Boot su Docker](https://www.youtube.com/playlist?list=PLoZNHBEyxFQGdNvr_5mMikHxuv2YHPjDz) - Giovanni Pace


### JavaScript

* [Corso base di Javascript](https://www.youtube.com/playlist?list=PLFLSwyN4GsWmcBvMr5tzsJy9TI8DbfWC5) - Simona Tocci
* [Corso di JavaScript](https://www.youtube.com/playlist?list=PLG5caACNVwzpIhlLACNZd6BvABWv_Ti4I) - Lacerba
* [Corso Javascript (ES6)](https://www.youtube.com/playlist?list=PL0qAPtx8YtJceyk5_NpNvLbbkrmfX9kkw) - Fabrizio Camuso
* [Corso Javascript Completo 2022](https://www.youtube.com/playlist?list=PLP5MAKLy8lP9FUx06-avV66mS8LXz7_Bb) - Edoardo Midali


#### Vue.js

* [Vue 2.x (corso base)](https://www.youtube.com/playlist?list=PL0qAPtx8YtJdUH44fvkzVxy9waP23I_bE) - Fabrizio Camuso


### Julia

* [Corso di linguaggio Julia](https://www.youtube.com/playlist?list=PL4GzWsD6ECaWvDCPuPB9OxdIye8IZXCuE) - Leonardo Boselli


### Machine Learning

* [Machine Learning in italiano col Pollo Watzlawick](https://www.youtube.com/playlist?list=PLa-sizbCyh93c0nSPAb8k5ZZeOq4SBIl9) - Piero Savastano
* [Machine Learning Reti Neurali](https://www.youtube.com/playlist?list=PL-tCoHPn6YlbCQHeyRxc_CQ0f1VZsUD6D) - Davide Manzoni (Brainlink)


### Misto

* [Api Rest vs GraphQL: La mini-serie per gli impazienti](https://www.youtube.com/playlist?list=PL2zaZp2LZxlv2XxmLm4dGP1tHfMjj7-kN) - Dario Balinzo
* [Programmazione Basic Commodore 64](https://www.youtube.com/playlist?list=PLCbSCJEIR6CrVT003ytijkO6kUrCT9VIT) - Mauro Cicolella


### Mobile

* [Corso Dart Italiano 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP9VP6KL4Q9ClYCuGhet59Od) - Edoardo Midali
* [Corso Flutter Italiano 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP93TzdGqBnuc2dK02Mz6-VH) - Edoardo Midali
* [DART & FLUTTER (per il mobile)](https://www.youtube.com/playlist?list=PL0qAPtx8YtJftaLnIroe7q9udsc9_qg6x) - Fabrizio Camuso


### Networking

* [Advanced Networking 2016](https://www.youtube.com/playlist?list=PLkbnRIR2azkIXO-ndOz7qBvVC38_wbOW8) - Hacklab Cosenza


### Pascal

* [Corso di programmazione in Pascal](https://www.youtube.com/playlist?list=PLO4y9a8lTpK1DS45Wljy0l5rMtVNIesRJ) - R. Rizzi, Università di Verona
* [Videocorso Pascal (Turbo e FPC)](https://www.youtube.com/playlist?list=PLC98ABC853EAEFD7F) - Fabrizio Camuso


### Php

* [Corso PHP Completo 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP_zqdyjNaPjh95NG40Op8he) - Edoardo Midali 


### Python

* [Corso Python 2016](https://www.youtube.com/playlist?list=PLA27EZBY5veOa-dbNIetJvyrAuoVy4zDD) - POuL Politecnico di Milano
* [Corso Python completo 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP8FAytdm2ncZbPioA9A2SgF) - Edoardo Midali
* [Corso rapido Python per principianti e per esempi](https://www.youtube.com/playlist?list=PL0qAPtx8YtJdbiBCoj4j6x_Ai6Vu9j5r9) - Fabrizio Camuso
* [Le Basi di Python - Corso Completo](https://www.programmareinpython.it/video-corso-python-base/) - Michele Saba
* [Programmazione ad Oggetti - Python](https://www.youtube.com/playlist?list=PLhlcRDRHVUzR2WHN9VTPZrawqRYHz5ALF) - Nicola Bicocchi


### Programmazione

* [Corso di C per sistemi Embedded](https://www.youtube.com/playlist?list=PLFPNVUgYSJN3szCCDYzDoai2ueDxZpCcb) - Davide Ferrero, Deid Lab
* [Programmazione](https://www.youtube.com/playlist?list=PLhEwqlL10MqN2eB3b4avX_DU3FK0EOYFa) - Gilberto Filè, Università di Padova
* [Tecniche di Programmazione (C/C++)](https://www.youtube.com/playlist?list=PLAQopGWlIcybv3YLRHGS4yZR00X3RvSBm) - L. Iocchi, D. Nardi, A. Pretto, Università La Sapienza di Roma


### Ruby

* [Corso Ruby 2013](https://www.youtube.com/playlist?list=PLA27EZBY5veNwghiX1buwSBziKV765N2t) - POuL Politecnico di Milano


### Sistemi Informativi

* [Sistemi Informativi Aziendali](https://didattica.polito.it/pls/portal30/sviluppo.videolezioni.vis?cor=233) - Fulvio Corno, Politecnico di Torino


### Sistemi Operativi

#### Linux

* [Corsi GNU/Linux Avanzati 2017](https://www.youtube.com/playlist?list=PLA27EZBY5veMZYKkqS2sQNPJSCGI1QniD) - POuL Politecnico di Milano
* [Corsi GNU/Linux Base 2017](https://www.youtube.com/playlist?list=PLA27EZBY5veNNqkeuFwjJFWserz6QLzS_) - POuL Politecnico di Milano


### Strumenti di sviluppo

* [Visual Studio 2019](https://www.youtube.com/playlist?list=PLgaOrAQwrg9J04dWnY-FF4SXUFt-TEQkE) - Mario De Ghetto


#### Git

* [Corso Git 2017](https://www.youtube.com/playlist?list=PLA27EZBY5veN02RzEr6Ecm7KcjWadthBh) - POuL Politecnico di Milano
* [Dominare GIT - La Guida Completa per Principianti e Professionisti](https://www.youtube.com/playlist?list=PLoZNHBEyxFQFc2fn3raEjovUK_BLWS0kO) - Giovanni Pace


#### Maven

* [Tutorial su Maven](https://www.youtube.com/playlist?list=PLjGYWJ4Dcy-f71M9YyNSk4RpLE5jobe7y) - Sonia Zorba


### Web

* [Computer grafica 2017/2018](https://www.youtube.com/playlist?list=PLUFFnpJdi99kXjntQ0LNPnLbRLjKzmQaC) - A. Bottino, Politecnico di Torino
* [Corso Bootstrap Italiano](https://www.youtube.com/playlist?list=PLP5MAKLy8lP_boQ2FBTSvA1fU73x2BiEv) - Edoardo Midali
* [Corso CSS 3 Completo 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP-a0MG-MFHKCISmj2Wg4vT6) - Edoardo Midali
* [Corso Flutter 2020](https://www.youtube.com/playlist?list=PLFD-5ZFcEgYX5q5pobSkQGfC6rMYy_puq) - Angelo Cassano
* [Corso HTML 5 Completo 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP8U-yYn6J4hGfcee4Tirieg) - Edoardo Midali
* [Corso HTML 5 Italiano 2023](https://www.youtube.com/playlist?list=PL6PilnEO6HWbTXL8nLSkp-875H-x-vhEo) - Manuel Ricci
* [Corso SEO Italiano 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP9OpFQyF2LnTWgtcoDLgYm7) - Edoardo Midali
* [Corso Typescript 2023](https://www.youtube.com/playlist?list=PLP5MAKLy8lP--n8iUsDsFMuTiKW5ooZE6) - Edoardo Midali
* [Mini Corso React / TypeScript / TSX 2023](https://www.youtube.com/playlist?list=PLUioGv_6G9YJw8uZb040obhcCi8tQX9IQ) - Fabio Biondi
* [Progettazione di applicazioni Web](https://www.youtube.com/playlist?list=PLE0AA1735F10543A6) - Fulvio Corno, S. Di Carlo, Politecnico di Torino


### Workshop

* [3D Printing Workshop 2015](https://www.youtube.com/playlist?list=PLA27EZBY5veNgfDUNft5kju0QAvLPPw2j) - POuL Politecnico di Milano
* [Workshop Calcolo Numerico 2014](https://www.youtube.com/playlist?list=PLA27EZBY5veNyyBiZxkjFE2KwAIKLkITL) - Alessandro Barenghi, POuL Politecnico di Milano
* [Workshop Python 2014](https://www.youtube.com/playlist?list=PLA27EZBY5veOFh1PdRdf7dc3DdBg-XctF) - Stefano Sanfilippo, POuL Politecnico di Milano
