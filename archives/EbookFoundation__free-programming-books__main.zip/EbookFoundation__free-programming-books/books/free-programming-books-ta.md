## Index

* [AR/VR/MR](#ar-vr-mr)
* [C++](#cpp)
* [Computer Vision](#computer-vision)
* [DevOps](#devops)
* [Ezhil](#ezhil)
* [Git/Github](#git-github)
* [Hadoop](#hadoop)
* [HTML and CSS](#html-and-css)
* [IOT](#iot)
* [JavaScript](#javascript)
* [Linux](#linux)
* [Machine Learning](#machine-learning)
* [MySQL](#mysql)
* [Pandas Python](#pandas-python)
* [PHP](#php)
* [Ruby](#ruby)
* [Selenium](#selenium)
* [Software Architecture](#software-architecture)
* [Software Testing](#software-testing)
* [Wordpress](#wordpress)


### AR VR MR

* [எளிய தமிழில் VR/AR/MR](https://freetamilebooks.com/ebooks/vr_ar_mr/) - இரா.அசோகன் (PDF)


### <a id="cpp"></a>C++

* [சி++ மொழி](https://www.nselva.com/book/C-plus-plus-book.pdf) - ந.செல்வகுமார் (PDF)


### Computer Vision

* [எளிய தமிழில் Computer Vision](https://freetamilebooks.com/ebooks/computer_vision/) - இரா.அசோகன் (PDF)


### DevOps

* [எளிய தமிழில் DevOps – கணினி அறிவியல்](https://freetamilebooks.com/ebooks/learn_devops_in_tamil/) - து.நித்யா (PDF)


### Ezhil

* [Write Code in Tamil-Ezhil Programming Language](https://ezhillang.wordpress.com/wp-content/uploads/2022/01/book-write-code-in-tamil-2015.pdf) - முத்தையா அண்ணாமலைை, என்.சொக்கன் (PDF)


### Git Github

* [எளிய தமிழில் கிட்(Git) – தொழில்நுட்பம்](https://freetamilebooks.com/ebooks/eliya_tamizhil_git/) - கி.முத்துராமலிங்கம் (PDF)


### Hadoop

* [எளிய தமிழில் Big Data](https://freetamilebooks.com/ebooks/learn-bigdata-in-tamil) - து.நித்யா (PDF)


### HTML and CSS

* [எளிய தமிழில் CSS](https://freetamilebooks.com/ebooks/learn-css-in-tamil/) - து.நித்யா (PDF)
* [எளிய தமிழில் HTML](https://noolaham.net/project/51/5090/5090.pdf) - வே.நவமோகன் (PDF)


### IOT

* [எளிய தமிழில் IOT](https://freetamilebooks.com/ebooks/iot/) - இரா.அசோகன் (PDF)


### JavaScript

* [எளிய தமிழில் JavaScript](https://freetamilebooks.com/ebooks/learn-javascript-in-tamil/) - து.நித்யா (PDF)
* [துவக்க நிலையாளர்களுக்கான JavaScript உரைநிரல்](https://freetamilebooks.com/ebooks/javascript_for_beginner/) - ச.குப்பன் (PDF)


### Linux

* [எளிய தமிழில் GNU/Linux - பாகம் - 1](https://freetamilebooks.com/ebooks/learn-gnulinux-in-tamil-part1/) - து.நித்யா (PDF)
* [எளிய தமிழில் GNU/Linux - பாகம் - 2](https://freetamilebooks.com/ebooks/learn-gnulinux-in-tamil-part2/) - து.நித்யா (PDF)


### Machine Learning

* [எளிய தமிழில் Deep Learning](https://freetamilebooks.com/ebooks/learn_deep_learning_in_tamil/) - து.நித்யா (PDF)
* [எளிய தமிழில் ML](https://freetamilebooks.com/ebooks/learn_machine_learning_in_tamil/) - து.நித்யா (PDF)


### MySQL

* [எளிய தமிழில் MySQL ](https://freetamilebooks.com/ebooks/learn-mysql-in-tamil) - து.நித்யா (PDF)
* [எளிய தமிழில் MySQL – பாகம் 2 ](https://freetamilebooks.com/ebooks/learn-mysql-in-tamil-part-2) - து.நித்யா (PDF)


### Pandas Python

* [எளிய தமிழில் Pandas](https://freetamilebooks.com/ebooks/learn_pandas_in_tamil/) - து.நித்யா (PDF)


### PHP

* [எளிய தமிழில் PHP](https://freetamilebooks.com/ebooks/learn-php-in-tamil/) - த.சீனிவாசன் (PDF)


### Ruby

* [எளிய இனிய கணினி மொழி Ruby](https://freetamilebooks.com/ebooks/learn-ruby-in-tamil/) - பிரியா சுந்தரமூர்த்தி (PDF)
* [ரூபி நண்பன்](https://freetamilebooks.com/ebooks/ruby_nanban/) - டக் ரைட், ஆடம் ஸ்டார் (PDF)


### Selenium

* [எளிய தமிழில் Selenium](https://freetamilebooks.com/ebooks/learn-selenium-in-tamil/) - து.நித்யா (PDF)


### Software Architecture

* [எளிய தமிழில் Agile/Scrum](https://freetamilebooks.com/ebooks/learn-agine-scrum-in-tamil) - த.சீனிவாசன் (PDF)


### Software Testing

* [எளிய தமிழில் சாப்ட்வேர் டெஸ்டிங் – தொழில்நுட்பம்](https://freetamilebooks.com/ebooks/eliya_tamilil_software_testing/) - கி.முத்துராமலிங்கம் (PDF)


### WordPress

* [எளிய தமிழில் WordPress](https://freetamilebooks.com/ebooks/learn-wordpress-in-tamil/) - த.சீனிவாசன் (PDF)
